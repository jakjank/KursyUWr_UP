#pragma once

#ifndef PROSTA_HPP
#define PROSTA_HPP
using namespace std;


class prosta
{
    double wsp_kier;
    double wyraz_wolny;

public:
    prosta(double a , double b);
};

#endif