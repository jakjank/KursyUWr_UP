#ifndef WEKTOR_HPP
#define WEKTOR_HPP
using namespace std;

class wektor
{
    double wx , wy;

public:
    wektor (double x , double y);

    double wsp_x();

    double wsp_y();
};

#endif