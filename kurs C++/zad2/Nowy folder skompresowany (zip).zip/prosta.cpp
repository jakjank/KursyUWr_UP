#include "prosta.hpp"
using namespace std;

prosta::prosta(double a , double b){
    wsp_kier = a;
    wyraz_wolny = b;
}