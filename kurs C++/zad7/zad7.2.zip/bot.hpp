#pragma once

#include <cstdlib>
#include <ctime>
#include "stan_gry.hpp"
#include "komunikacja.hpp"

pair<int,int> bot(Plansza plansza);

pair<int,int> madry_bot(Plansza plansza);