#include "komunikacja.hpp"

int main()
{
    graj();
    return 0;
}