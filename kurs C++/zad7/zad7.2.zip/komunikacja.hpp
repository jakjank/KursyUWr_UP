#pragma once
#include "stan_gry.hpp"
#include "bot.hpp"

void graj();
void rysuj_plansze(Plansza plansza);
pair<int,int> konwersja(int a, string b);