#include "stale.hpp"

pi::pi(){}
fi::fi(){}
e::e(){}

string pi::zapis()
{
    return "pi";
}

string fi::zapis()
{
    return "fi";
}

string e::zapis()
{
    return "e";
}

double pi::oblicz()
{
    return 3.141;
}

double fi::oblicz()
{
    return 1.618;
}

double e::oblicz()
{
    return 2.718;
}