#include <random>
#include <iostream>
#include <vector>
#include <array>
#include <algorithm>

using namespace std;

template <int mini, int maxi>
auto generuj = []() {
    return ((rand() % (maxi - mini)) + mini);
};

auto czy_pierwsza = [](int number) {
    if (number < 2)
        return false;
    for (int i = 2; i * i <= number; ++i) {
        if (number % i == 0)
            return false;
    }
    return true;
};

int main()
{
    srand(time(NULL));

    int t[10];
    array<int, 10> a;
    vector<int> v(10);

    generate(begin(t), end(t), generuj<1,10>);
    generate(a.begin(), a.end(), generuj<50, 100>);
    generate(v.begin(), v.end(), generuj<1,100>);

    for_each(begin(t), end(t), [](int x){cout << x << " ";});
    cout << endl;
    for_each(a.begin(), a.end(), [](int x){cout << x << " ";});
    cout << endl;
    for_each(v.begin(), v.end(), [](int x){cout << x << " ";});
    cout << endl;
    
    // cos w tym stylu?
    int t_pierwsze[10];
    array<int,10> a_pierwsze;
    vector<int> v_pierwsze(0);

    copy_if(begin(t), end(t), t_pierwsze, czy_pierwsza);
    copy_if(a.begin(), a.end(), t_pierwsze, czy_pierwsza);
    copy_if(v.begin(), v.end(), t_pierwsze, czy_pierwsza);

    // for_each(begin(t_pierwsze), end(t_pierwsze), [](int x){cout << x << " ";});
    // cout << endl;
    // for_each(a_pierwsze.begin(), a_pierwsze.end(), [](int x){cout << x << " ";});
    // cout << endl;
    // for_each(v_pierwsze.begin(), v_pierwsze.end(), [](int x){cout << x << " ";});
    // cout << endl;

    return 0;
}