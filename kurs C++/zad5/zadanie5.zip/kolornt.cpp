#include "kolornt.hpp"

using namespace std;

kolornt::kolornt(int r, int g, int b, int d, string e):kolor(r,g,b), kolortransparentny(r,g,b,d), kolornazwany(r,g,b,e){}